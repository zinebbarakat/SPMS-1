#ifndef Credentials_h
#define Credentials_h

char ssid[] = "dlink";             // your network SSID (name)
char pass[] = "";         // your network password

char user[]         = "pii2_NewLifeSystems";              // MySQL user login username
char password[]     = "secure_password";          // MySQL user login password

#endif    //Credentials_h
