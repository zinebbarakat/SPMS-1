
#include "Credentials.h"
#include <MySQL_Generic.h>

//Imports for the specific project
#include<time.h>
#include <DHT.h>
DHT dht(15, DHT11);

//Pin definition
#define HUMIDITY_SENSOR_PIN 2
#define LDR_SENSOR_PIN 4

#define MYSQL_DEBUG_PORT      Serial

// Debug Level from 0 to 4
#define _MYSQL_LOGLEVEL_      1

IPAddress server(195, 235, 211, 197);

uint16_t server_port = 3306;    //3306;

char default_database[] = "pii2_NewLifeSystems";           //"test_arduino";
char default_table[]    = "measurement";          //"test_arduino";

//Variables to pass to the query
double value;
int sensor_ID;
char timestamp[20];
int userID = 1;

//Servers for time
const char* NTP_SERVER_1 = "pool.ntp.org";
const char* NTP_SERVER_2 = "time.nist.gov";

MySQL_Connection conn((Client *)&client);

MySQL_Query *query_mem;

WiFiClient    net;

void setup()
{
  //Initializing DHT sensor 
  dht.begin();
  delay(2000);

  Serial.begin(115200);
  while (!Serial && millis() < 5000); // wait for serial port to connect

  MYSQL_DISPLAY1("\nStarting Artemisv1 on", ARDUINO_BOARD);
  MYSQL_DISPLAY(MYSQL_MARIADB_GENERIC_VERSION);

  // Begin WiFi section
  MYSQL_DISPLAY1("Connecting to", ssid);
  
  WiFi.begin(ssid, pass);
  
  while (WiFi.status() != WL_CONNECTED) 
  {
    delay(500);
    MYSQL_DISPLAY0(".");
  }

  //Setting up time
  setenv("TZ", "CET-1CEST,M3.5.0,M10.5.0/3", 1);
  tzset();
  configTime(0, 0, NTP_SERVER_1, NTP_SERVER_2);

  // print out info about the connection:
  MYSQL_DISPLAY1("Connected to network. My IP address is:", WiFi.localIP());

  MYSQL_DISPLAY3("Connecting to SQL Server @", server, ", Port =", server_port);
  MYSQL_DISPLAY5("User =", user, ", PW =", password, ", DB =", default_database);
}

void runInsert()
{
  // Initiate the query class instance
  MySQL_Query query_mem = MySQL_Query(&conn);

  // Sample query
  String INSERT_SQL = String("INSERT INTO ") + default_database + "." + default_table 
                   + " (measurementValue, timeStamp, sensor_ID, user_ID) VALUES (" + value + ", '" + timestamp + "', " + sensor_ID + ", " + userID + ")";


  if (conn.connected())
  {
    MYSQL_DISPLAY(INSERT_SQL);
    
    // Execute the query
    // KH, check if valid before fetching
    if ( !query_mem.execute(INSERT_SQL.c_str()) )
    {
      MYSQL_DISPLAY("Insert error");
    }
    else
    {
      MYSQL_DISPLAY("Data Inserted.");
    }
  }
  else
  {
    MYSQL_DISPLAY("Disconnected from Server. Can't insert.");
  }
}

void loop()
{
  MYSQL_DISPLAY("Connecting...");
  
  //if (conn.connect(server, server_port, user, password))
  if (conn.connectNonBlocking(server, server_port, user, password) != RESULT_FAIL)
  {
    delay(500);
    
    //Setting up time for all measurements this cycle
    struct tm timeinfo;
    if (!getLocalTime(&timeinfo)) {
      Serial.println("Failed to obtain time");
      return;
  }

    // Format into YYYY-MM-DD HH:MM:SS
    snprintf(timestamp, sizeof(timestamp),
      "%04d-%02d-%02d %02d:%02d:%02d",
      timeinfo.tm_year + 1900,
      timeinfo.tm_mon  +   1,
      timeinfo.tm_mday,
      timeinfo.tm_hour,
      timeinfo.tm_min,
      timeinfo.tm_sec
  );

    //Setting up values for the temperature measurement
    value = dht.readTemperature();
    sensor_ID = 1;

    Serial.print("Temperature update: ");
    Serial.print(value);
    Serial.println(" C ");
    runInsert();
    
    //Setting up values for moisture measurement
    int hsensorValue = analogRead(HUMIDITY_SENSOR_PIN);
    value = 100 - ((hsensorValue/4095.0)*100);
    sensor_ID = 4;

    Serial.print("Humidity update: ");
    Serial.print(value);
    Serial.println(" % ");
    runInsert();

    //Setting up values for light sensor
    int lightState = digitalRead(LDR_SENSOR_PIN);
    sensor_ID = 3;

    if(lightState == HIGH){
    value = 0;
    Serial.print("Light update: Low Light! ");
    runInsert();

  } else {
    value = 100;
    Serial.print("Light update: Optimal Light! ");
    runInsert();
  }


    conn.close();                     // close the connection
  } 
  else 
  {
    MYSQL_DISPLAY("\nConnect failed. Trying again on next iteration.");
  }

  MYSQL_DISPLAY("\nSleeping...");
  MYSQL_DISPLAY("================================================");
 
  delay(10000);
}
